#ifndef MY_STRLEN_H
#define MY_STRLEN_H
unsigned long my_strlen(const char *s);
#endif
