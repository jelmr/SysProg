#ifndef MY_STRPBRK_H
#define MY_STRPBRK_H
const char *my_strpbrk(const char *s1, const char *s2);
#endif
