#ifndef MY_STRLCAT_H
#define MY_STRLCAT_H
unsigned my_strlcat(char *dst, const char *src, unsigned n);
#endif
