#ifndef MY_MEMSET_H
#define MY_MEMSET_H
void *my_memset(void *dst, int c, unsigned n);
#endif
