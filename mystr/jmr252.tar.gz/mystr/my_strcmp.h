#ifndef MY_STRCMP_H
#define MY_STRCMP_H
int my_strcmp(const char *s1, const char *s2);
#endif
