#ifndef MY_STRCHR_H
#define MY_STRCHR_H
const char *my_strchr(const char *s, int c);
#endif
