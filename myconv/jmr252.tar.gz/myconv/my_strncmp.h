#ifndef MY_STRNCMP_H
#define MY_STRNCMP_H
int my_strncmp(const char *s1, const char *s2, unsigned n);
#endif
