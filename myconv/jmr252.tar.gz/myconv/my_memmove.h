#ifndef MY_MEMMOVE_H
#define MY_MEMMOVE_H
void *my_memmove(void *dst, const void *src, unsigned n);
#endif
