#ifndef MY_MEMCPY_H
#define MY_MEMCPY_H
void *my_memcpy(void *dst, const void *src, unsigned n);
#endif
