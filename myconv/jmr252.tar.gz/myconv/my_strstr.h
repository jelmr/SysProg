#ifndef MY_STRSTR_H
#define MY_STRSTR_H
const char *my_strstr(const char *s1, const char *s2);
#endif
