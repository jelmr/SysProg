#ifndef MY_STRLCPY_H
#define MY_STRLCPY_H
unsigned my_strlcpy(char *dst, const char *src, unsigned n);
#endif
