#ifndef MY_STRRCHR_H
#define MY_STRRCHR_H
const char *my_strrchr(const char *s, int c);
#endif
